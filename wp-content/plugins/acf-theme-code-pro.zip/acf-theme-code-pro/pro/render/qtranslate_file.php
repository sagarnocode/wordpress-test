<?php
// qTranslate File field

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

include( ACFTCP_Core::$plugin_path . 'render/file.php' );
